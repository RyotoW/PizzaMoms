Welcome to \m,  This is a 2d GBA-style RPG. Here are some basic controls to interact with the map.

WASD and arrow keys to move.

Enter Key to interact with other NPCs or objects within the video game.

Enter Key as well to go past text boxes.