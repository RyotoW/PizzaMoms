window.Actions = {
  damage1: {
    name: "Whomp!",
    description: "Pillowy pack of dough",
    success: [
      { type: "textMessage", text: "{CASTER} uses {ACTION}!"},
      { type: "animation", animation: "spin"},
      { type: "stateChange", damage: 10}
    ]
  },
  saucyStatus: {
    name: "Ketchup-Kraze",
    description: "Sweet taste of Ketch-up",
    targetType: "friendly",
    success: [
      { type: "textMessage", text: "{CASTER} uses {ACTION}!"},
      { type: "animation", animation: "splash", color: "#ff0000"},
      { type: "stateChange", status: { type: "saucy", expiresIn: 3 } }
    ]
  },
  clumsyStatus: {
    name: "Olive-Fingers",
    description: "Slippery mess of deliciousness",
    success: [
      { type: "textMessage", text: "{CASTER} uses {ACTION}!"},
      { type: "animation", animation: "glob", color: "#dafd2a"},
      { type: "stateChange", status: { type: "clumsy", expiresIn: 5 } },
      { type: "textMessage", text: "{TARGET} is slipping all around!"},
    ]
    
  },
  
  frozenStatus: {
    name: "Refrigeratte",
    description: "Icy and hard to thaw",
    success: [
      { type: "textMessage", text: "{CASTER} uses {ACTION}!"},
      { type: "animation", animation: "frozen", color: "#2ecaf9"},
      { type: "stateChange", status: { type: "frozen", expiresIn: 3 } },
      { type: "textMessage", text: "{TARGET} is frozen in place!"},
    ]
  },


  
//ITEMS!!!
  item_recoverStatus: {
    name: "Heating Lamp",
    description: "Warm you up and thaw ice",
    targetType: "friendly",
    success: [
    { type: "textMessage", text: "{CASTER} uses a {ACTION}!"},
    { type: "stateChange", status: null},
    { type: "textMessage", text: "{CASTER} is feeling fresh!"}
    ]
  },
    item_recoverHp: {
    name: "Parmesan",
    description: "Cheesy recovery",
    targetType: "friendly",
    success: [
    { type: "textMessage", text: "{CASTER} sprinkles on some {ACTION}!"},
    { type: "stateChange", recover: 10},
    { type: "textMessage", text: "{CASTER} recovers HP!"}
    ]
  },
}